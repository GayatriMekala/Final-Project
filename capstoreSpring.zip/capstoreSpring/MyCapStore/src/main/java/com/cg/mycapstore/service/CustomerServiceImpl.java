package com.cg.mycapstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mycapstore.bean.Customer;
import com.cg.mycapstore.dao.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository custRepo;

	@Override
	public Customer customerLogin(String email, String password) {

		Customer customer = new Customer();
		customer = custRepo.getCustomer(email);
		return customer;
	}

	@Override
	public void updateCustomer(String email, Customer updatedCustomer) {
		Customer customer = custRepo.getCustomer(email);
		customer.setFirstName(updatedCustomer.getFirstName());
		customer.setLastName(updatedCustomer.getLastName());
		customer.setPhone(updatedCustomer.getPhone());
		customer.setAddress(updatedCustomer.getAddress());
		custRepo.save(customer);
	}

}
